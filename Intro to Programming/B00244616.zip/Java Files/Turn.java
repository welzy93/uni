
public class Turn {

	public int throwOne;
	public int throwTwo;
	public int throwThree;
	public int throwTotal;
	

}
