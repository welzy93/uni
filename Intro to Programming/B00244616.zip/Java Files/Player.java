
public class Player {
	
	public static int NoPlayer;
	public static boolean gameOver = false;
	
	public String name;
	public int total = 501;
	

}

